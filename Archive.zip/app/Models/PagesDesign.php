<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PagesDesign extends Model
{
    protected $table = 'PagesDesign';
}